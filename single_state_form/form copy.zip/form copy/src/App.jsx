import React from 'react';
import Form from './components/Form';

const App = () => {
  return (
    <div>
      <h1>React Single State Object Form</h1>
      <Form />
    </div>
  );
};

export default App;
